.. cmake-module:: ../../Modules/FindCABLE.cmake
