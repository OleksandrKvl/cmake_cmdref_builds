.. cmake-module:: ../../Modules/CheckOBJCXXSourceCompiles.cmake
