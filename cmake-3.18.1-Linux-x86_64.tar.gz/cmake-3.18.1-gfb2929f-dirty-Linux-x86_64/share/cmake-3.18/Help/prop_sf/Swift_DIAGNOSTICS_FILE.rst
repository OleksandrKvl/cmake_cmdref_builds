Swift_DIAGNOSTICS_FILE
----------------------

This property controls where the Swift diagnostics are serialized.
