SYMBOLIC
--------

Is this just a name for a rule.

If ``SYMBOLIC`` (boolean) is set to ``True`` the build system will be informed
that the source file is not actually created on disk but instead used
as a symbolic name for a build rule.
